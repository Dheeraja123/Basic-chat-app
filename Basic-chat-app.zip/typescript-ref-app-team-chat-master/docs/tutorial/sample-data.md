---
id: sample-data
title: Changing the Sample Data
sidebar_label: Sample Data
---

When you run the app for the first time, it runs the `setup/populate.js` script to populate sample data for users, spaces, and memberships into your PubNub keys. 
You can make changes to the sample data by editing the `setup/team-chat-initialization-data.json` file.
To update the data on the server, re-run the populate script with a new PubNub keyset.
