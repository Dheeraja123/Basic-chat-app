---
id: overview
title: Overview
sidebar_label: Overview
---

This tutorial convers how Team Chat’s key features are put together, and how you can add them in your own applications.
Each section focuses on one feature of the application.
Although the sections build on each other, feel free to skip around and explore the features that interest you.