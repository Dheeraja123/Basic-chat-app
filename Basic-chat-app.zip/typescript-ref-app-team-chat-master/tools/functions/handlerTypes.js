module.exports = {
  beforePublish: "js-before-publish",
  afterPublish: "js-after-publish",
  beforeSignal: "js-before-signal",
  afterSignal: "js-after-signal",
  afterPresence: "js-after-presence",
  onRequest: "js-on-rest",
  onInterval: "js-on-interval"
};