// Define built-in bootstrap data for this application
const preloadedState = {};

export default preloadedState;
